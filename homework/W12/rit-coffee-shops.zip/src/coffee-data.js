var coffeeShops = [
{
	latitude:43.084156,
	longitude:-77.67514,
	title:"Artesano Bakery & Cafe"
},

{
	latitude:43.083866,
	longitude:-77.66901,
	title:"Beanz"
},

{
	latitude:43.082520,
	longitude:-77.67980,
	title:"Midnight Oil"
},

{
	latitude:43.086678,
	longitude:-77.669014,
	title:"The College Grind"
},

{
	latitude:43.082634,
	longitude:-77.68004,
	title:"The Cafe & Market at Crossroads"
},

{
	latitude:43.08382,
	longitude:-77.674805,
	title:"RITZ Sports Zone"
},

{
	latitude:43.086502,
	longitude:-77.66912,
	title:"The Commons"
},

{
	latitude:43.08324,
	longitude:-77.68105,
	title:"The Market at Global Village"
},

{
	latitude:43.08384,
	longitude:-77.67457,
	title:"Brick City Cafe"
},

{
	latitude:43.084904,
	longitude:-77.6676,
	title:"Corner Store"
},

{
	latitude:43.08464,
	longitude:-77.680145,
	title:"CTRL ALT DELi"
},

{
	latitude:43.08359,
	longitude:-77.66921,
	title:"Gracie's"
}


];

module.exports.coffeeShops = coffeeShops;